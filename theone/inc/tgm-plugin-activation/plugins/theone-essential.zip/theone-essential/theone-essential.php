<?php
/**
 * Plugin Name: TheOne Essential
 * Plugin URI: https://themeforest.net/user/codexcoder
 * Description: The essential plugin.
 * Author: CodexCoder
 * Author URI: http://codexcoder.com/
 * Version: 1.0.0
 * Text Domain: theonetext
 */
function theone_admin_menu_enqueue_style() {
    wp_enqueue_style('theone-admin-style', plugins_url( 'css/theone-admin-style.css', __FILE__ ), null);
}
add_action( 'admin_enqueue_scripts', 'theone_admin_menu_enqueue_style');


if(! function_exists('theone_social_share')): 
function theone_social_share() {
	// Get current page URL
	$sb_url = urlencode(get_permalink());
	// Get current page title
	$sb_title = str_replace( ' ', '%20', get_the_title());
	// Get Post Thumbnail for pinterest
	$sb_thumb = wp_get_attachment_url(get_post_thumbnail_id());
	// Construct sharing URL without using any script
	$twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url.'&amp;via=wpvkp';
	$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
	// Based on popular demand added Pinterest too
	$pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;media='.$sb_thumb.'&amp;description='.$sb_title;
	$gplusURL ='https://plus.google.com/share?url='.$sb_title.'';
	// Add sharing button at the end of page/page content
	?>
	<li><a target="popup" title="Facebook" onclick="window.open('<?php echo $facebookURL;?>','popup','width=600,height=600'); return false;" href="<?php echo $facebookURL; ?>"><i class="fa fa-facebook"></i></a></li>

	<li><a target="popup" title="Twitter" onclick="window.open('<?php echo $twitterURL;?>','popup','width=600,height=600'); return false;" href="<?php echo $twitterURL; ?>"><i class="fa fa-twitter"></i></a></li>

	<li><a target="popup" title="Google Plus" onclick="window.open('<?php echo $gplusURL;?>','popup','width=600,height=600'); return false;" href="<?php echo $gplusURL; ?>"><i class="fa fa-google-plus"></i></a></li>
	<li><a target="popup" title="Pinterest" onclick="window.open('<?php echo $pinterestURL;?>','popup','width=600,height=600'); return false;" href="<?php echo $pinterestURL; ?>"><i class="fa fa-pinterest"></i></a></li>
<?php } endif; 

/**
*  TheOne Custom Post type
*/


 /** 
 *  Portfolio
 */
 if(!class_exists('TheOne_Portfolio_Post_Type')) :

    class TheOne_Portfolio_Post_Type {

        public static $post_type        = 'portfolio';
        public static $texonomy_type    = 'portfolio_cat';
        public static $texonomy_type_tag = 'portfolio_tag';
        public static $menu_position    = 5;

        public static function register(){

        $labels = array(
        'name'               => esc_html__( 'Portfolios',  'theonetext' ),
        'singular_name'      => esc_html__( 'Portfolio', 'theonetext'  ),
        'menu_name'          => esc_html__( 'Portfolios',  'theonetext'  ),
        'name_admin_bar'     => esc_html__( 'Portfolio', 'theonetext'  ),
        'add_new'            => esc_html__( 'Add New',  'theonetext'  ),
        'add_new_item'       => esc_html__( 'Add New Portfolio', 'theonetext'  ),
        'new_item'           => esc_html__( 'New Portfolio', 'theonetext'  ),
        'edit_item'          => esc_html__( 'Edit Portfolio', 'theonetext'  ),
        'view_item'          => esc_html__( 'View Portfolio', 'theonetext'  ),
        'all_items'          => esc_html__( 'All Portfolios', 'theonetext'  ),
        'search_items'       => esc_html__( 'Search Portfolios', 'theonetext'  ),
        'parent_item_colon'  => esc_html__( 'Parent Portfolios:', 'theonetext'  ),
        'not_found'          => esc_html__( 'No Portfolios found.', 'theonetext'  ),
        'not_found_in_trash' => esc_html__( 'No Portfolios found in Trash.', 'theonetext'  )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title', 'thumbnail', 'editor'  ),
        'menu_icon'          => 'dashicons-images-alt2',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();

    /**
     * Texonomy Register 
     */
    //category
    $port_labels = array(
        'name'              => esc_html__( 'Portfolio Categories', 'theonetext' ),
        'singular_name'     => esc_html__( 'Category', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Categories', 'theonetext' ),
        'all_items'         => esc_html__( 'All Categories', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Category', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Category:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Category', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Category', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Category', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Category Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Categories', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type ),
    );

    register_taxonomy( self::$texonomy_type , array( self::$post_type ), $port_args );
    //tags
    $port_labels = array(
        'name'              => esc_html__( 'Portfolio Tags', 'theonetext' ),
        'singular_name'     => esc_html__( 'Tag', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Tags', 'theonetext' ),
        'all_items'         => esc_html__( 'All Tags', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Tag', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Tag:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Tag', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Tag', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Tag', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Tag Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Tags', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type_tag ),
    );

    register_taxonomy( self::$texonomy_type_tag , array( self::$post_type ), $port_args );
        }
    }

endif;

/**
 * Testimonial Testimonial
 */

if(!class_exists('TheOne_Clint_Feedback')) :

    class TheOne_Clint_Feedback {

        public static $post_type        = 'testimonial';
        public static $texonomy_type    = 'testimonial_cat';
        public static $texonomy_type_tag    = 'testimonial_tag';
        public static $menu_position    = 5;

        public static function register(){

        $labels = array(
        'name'               => esc_html__( 'Testimonial',  'theonetext' ),
        'singular_name'      => esc_html__( 'Testimonial', 'theonetext'  ),
        'menu_name'          => esc_html__( 'Testimonial',  'theonetext'  ),
        'name_admin_bar'     => esc_html__( 'Testimonial', 'theonetext'  ),
        'add_new'            => esc_html__( 'Add New',  'theonetext'  ),
        'add_new_item'       => esc_html__( 'Add New Testimonial', 'theonetext'  ),
        'new_item'           => esc_html__( 'New Testimonial', 'theonetext'  ),
        'edit_item'          => esc_html__( 'Edit Testimonial', 'theonetext'  ),
        'view_item'          => esc_html__( 'View Testimonial', 'theonetext'  ),
        'all_items'          => esc_html__( 'All Testimonial', 'theonetext'  ),
        'search_items'       => esc_html__( 'Search Testimonial', 'theonetext'  ),
        'parent_item_colon'  => esc_html__( 'Parent Testimonial:', 'theonetext'  ),
        'not_found'          => esc_html__( 'No Testimonial found.', 'theonetext'  ),
        'not_found_in_trash' => esc_html__( 'No Testimonial found in Trash.', 'theonetext'  )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title', 'editor'),
        'menu_icon'          => 'dashicons-format-chat',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();

    /**
     * Texonomy Register
     */
    //category
    $port_labels = array(
        'name'              => esc_html__( 'Testimonial Categories', 'theonetext' ),
        'singular_name'     => esc_html__( 'Category', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Categories', 'theonetext' ),
        'all_items'         => esc_html__( 'All Categories', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Category', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Category:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Category', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Category', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Category', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Category Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Categories', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type ),
    );

    register_taxonomy( self::$texonomy_type , array( self::$post_type ), $port_args );
    //tags
    $port_labels = array(
        'name'              => esc_html__( 'Testimonial Tags', 'theonetext' ),
        'singular_name'     => esc_html__( 'Tag', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Tags', 'theonetext' ),
        'all_items'         => esc_html__( 'All Tags', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Tag', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Tag:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Tag', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Tag', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Tag', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Tag Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Tags', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type_tag ),
    );

    register_taxonomy( self::$texonomy_type_tag , array( self::$post_type ), $port_args );

        }
    }

endif;

 /* 
 *  Services
 */
 if(!class_exists('TheOne_Service_Post_Type')) :

    class TheOne_Service_Post_Type {

        public static $post_type        = 'service';
        public static $texonomy_type    = 'service_cat';
        public static $texonomy_type_tag    = 'service_tag';
        public static $menu_position    = 5;

        public static function register(){

        $labels = array(
            'name'               => esc_html__( 'Services',  'theonetext' ),
            'singular_name'      => esc_html__( 'Service', 'theonetext'  ),
            'menu_name'          => esc_html__( 'Services',  'theonetext'  ),
            'name_admin_bar'     => esc_html__( 'Service', 'theonetext'  ),
            'add_new'            => esc_html__( 'Add New',  'theonetext'  ),
            'add_new_item'       => esc_html__( 'Add New Service', 'theonetext'  ),
            'new_item'           => esc_html__( 'New Service', 'theonetext'  ),
            'edit_item'          => esc_html__( 'Edit Service', 'theonetext'  ),
            'view_item'          => esc_html__( 'View Service', 'theonetext'  ),
            'all_items'          => esc_html__( 'All Services', 'theonetext'  ),
            'search_items'       => esc_html__( 'Search Services', 'theonetext'  ),
            'parent_item_colon'  => esc_html__( 'Parent Services:', 'theonetext'  ),
            'not_found'          => esc_html__( 'No Services found.', 'theonetext'  ),
            'not_found_in_trash' => esc_html__( 'No Services found in Trash.', 'theonetext'  )
        );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title', 'editor', 'thumbnail'  ),
        'menu_icon'          => 'dashicons-megaphone',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();
    /**
     * Texonomy Register
     */
    //category
    $port_labels = array(
        'name'              => esc_html__( 'Services Categories', 'theonetext' ),
        'singular_name'     => esc_html__( 'Category', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Categories', 'theonetext' ),
        'all_items'         => esc_html__( 'All Categories', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Category', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Category:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Category', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Category', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Category', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Category Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Categories', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type ),
    );

    register_taxonomy( self::$texonomy_type , array( self::$post_type ), $port_args );
    //tags
    $port_labels = array(
        'name'              => esc_html__( 'Services Tags', 'theonetext' ),
        'singular_name'     => esc_html__( 'Tag', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Tags', 'theonetext' ),
        'all_items'         => esc_html__( 'All Tags', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Tag', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Tag:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Tag', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Tag', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Tag', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Tag Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Tags', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type_tag ),
    );

    register_taxonomy( self::$texonomy_type_tag , array( self::$post_type ), $port_args );

        }
    }

endif;

 /* 
 *  Pricing Table
 */
 if(!class_exists('TheOne_Pricing_Post_Type')) :

    class TheOne_Pricing_Post_Type {

        public static $post_type        = 'pricing';
        public static $texonomy_cats    = 'pricing_cat';
        public static $texonomy_tags    = 'pricing_tag';
        public static $menu_position    = 5;

        public static function register(){

        $labels = array(
        'name'               => esc_html__( 'Pricing Table',  'theonetext' ),
        'singular_name'      => esc_html__( 'Pricing', 'theonetext'  ),
        'menu_name'          => esc_html__( 'Pricing Table',  'theonetext'  ),
        'name_admin_bar'     => esc_html__( 'Pricing', 'theonetext'  ),
        'add_new'            => esc_html__( 'Add New',  'theonetext'  ),
        'add_new_item'       => esc_html__( 'Add New Pricing', 'theonetext'  ),
        'new_item'           => esc_html__( 'New Pricing', 'theonetext'  ),
        'edit_item'          => esc_html__( 'Edit Pricing', 'theonetext'  ),
        'view_item'          => esc_html__( 'View Pricing', 'theonetext'  ),
        'all_items'          => esc_html__( 'All Pricing Table', 'theonetext'  ),
        'search_items'       => esc_html__( 'Search Pricings', 'theonetext'  ),
        'parent_item_colon'  => esc_html__( 'Parent Pricings:', 'theonetext'  ),
        'not_found'          => esc_html__( 'No Pricings found.', 'theonetext'  ),
        'not_found_in_trash' => esc_html__( 'No Pricings found in Trash.', 'theonetext'  )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title',),
        'menu_icon'          => 'dashicons-editor-table',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();

    /**
     * Texonomy Register
     */
    //category
    $port_labels = array(
        'name'              => esc_html__( 'Pricing Plan Categories', 'theonetext' ),
        'singular_name'     => esc_html__( 'Category', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Categories', 'theonetext' ),
        'all_items'         => esc_html__( 'All Categories', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Category', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Category:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Category', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Category', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Category', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Category Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Categories', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_cats ),
    );

    register_taxonomy( self::$texonomy_cats , array( self::$post_type ), $port_args );
    //tags
    $port_labels = array(
        'name'              => esc_html__( 'Pricing Plan Tags', 'theonetext' ),
        'singular_name'     => esc_html__( 'Tag', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Tags', 'theonetext' ),
        'all_items'         => esc_html__( 'All Tags', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Tag', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Tag:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Tag', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Tag', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Tag', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Tag Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Tags', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_tags ),
    );

    register_taxonomy( self::$texonomy_tags , array( self::$post_type ), $port_args );

        }
    }

endif;


 /* 
 *  Team Members
 */
 if(!class_exists('TheOne_Member_Post_Type')) :

    class TheOne_Member_Post_Type {

        public static $post_type        = 'member';
        public static $texonomy_type    = 'member_cat';
        public static $texonomy_type_tag    = 'member_tag';
        public static $menu_position    = 5;

        public static function register(){

        $labels = array(
        'name'               => esc_html__( 'Team Member',  'theonetext' ),
        'singular_name'      => esc_html__( 'Member', 'theonetext'  ),
        'menu_name'          => esc_html__( 'Team Members',  'theonetext'  ),
        'name_admin_bar'     => esc_html__( 'Member', 'theonetext'  ),
        'add_new'            => esc_html__( 'Add New',  'theonetext'  ),
        'add_new_item'       => esc_html__( 'Add New Member', 'theonetext'  ),
        'new_item'           => esc_html__( 'New Member', 'theonetext'  ),
        'edit_item'          => esc_html__( 'Edit Member', 'theonetext'  ),
        'view_item'          => esc_html__( 'View Member', 'theonetext'  ),
        'all_items'          => esc_html__( 'All Members', 'theonetext'  ),
        'search_items'       => esc_html__( 'Search Member', 'theonetext'  ),
        'parent_item_colon'  => esc_html__( 'Parent Member:', 'theonetext'  ),
        'not_found'          => esc_html__( 'No Member found.', 'theonetext'  ),
        'not_found_in_trash' => esc_html__( 'No Member found in Trash.', 'theonetext'  )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-groups',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();

    /**
     * Texonomy Register
     */
    //Category
    $port_labels = array(
        'name'              => esc_html__( 'Team Member Categories', 'theonetext' ),
        'singular_name'     => esc_html__( 'Category', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Categories', 'theonetext' ),
        'all_items'         => esc_html__( 'All Categories', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Category', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Category:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Category', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Category', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Category', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Category Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Categories', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type ),
    );

    register_taxonomy( self::$texonomy_type , array( self::$post_type ), $port_args );

    //tags
    $port_labels = array(
        'name'              => esc_html__( 'Team Member Tags', 'theonetext' ),
        'singular_name'     => esc_html__( 'Tag', 'theonetext' ),
        'search_items'      => esc_html__( 'Search Tags', 'theonetext' ),
        'all_items'         => esc_html__( 'All Tags', 'theonetext' ),
        'parent_item'       => esc_html__( 'Parent Tag', 'theonetext' ),
        'parent_item_colon' => esc_html__( 'Parent Tag:', 'theonetext' ),
        'edit_item'         => esc_html__( 'Edit Tag', 'theonetext' ),
        'update_item'       => esc_html__( 'Update Tag', 'theonetext' ),
        'add_new_item'      => esc_html__( 'Add New Tag', 'theonetext' ),
        'new_item_name'     => esc_html__( 'New Tag Name', 'theonetext' ),
        'menu_name'         => esc_html__( 'Tags', 'theonetext' ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type_tag ),
    );

    register_taxonomy( self::$texonomy_type_tag , array( self::$post_type ), $port_args );

        }
    }

endif;

//PostType Registretion
if(!function_exists('theone_custom_post')) :

    function theone_custom_post(){
        TheOne_Portfolio_Post_Type::register();
        TheOne_Clint_Feedback::register();
        TheOne_Service_Post_Type::register();
        TheOne_Pricing_Post_Type::register();
        TheOne_Member_Post_Type::register();
    }
endif;

add_action( 'init','theone_custom_post');

//Change Title placeholder
function theone_change_title_text( $title ){
     $screen = get_current_screen();

     if  ( 'testimonial' == $screen->post_type ) {
          $title = esc_html__( 'Enter Client Name', 'theonetext'  );
     }
     if  ( 'service' == $screen->post_type ) {
          $title = esc_html__( 'Enter Service', 'theonetext'  );
     }
     if  ( 'pricing' == $screen->post_type ) {
          $title = esc_html__( 'Enter Pricing Plan', 'theonetext'  );
     }
     if  ( 'member' == $screen->post_type ) {
          $title = esc_html__( 'Enter Member Name', 'theonetext'  );
     }
  
     return $title;
}
  
add_filter( 'enter_title_here', 'theone_change_title_text' );

